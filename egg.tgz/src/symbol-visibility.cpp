// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("symbol visibility\n", stdout);
  return lionss_run_workload("symbol-visibility");
}
