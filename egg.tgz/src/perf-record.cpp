// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("perf record"); }
int main(){
  announce();
  return lionss_run_workload("perf-record");
}
