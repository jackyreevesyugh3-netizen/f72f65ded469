// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("haiku build"); }
int main(){
  announce();
  return lionss_run_workload("haiku-build");
}
