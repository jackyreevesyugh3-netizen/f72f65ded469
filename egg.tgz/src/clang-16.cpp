// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("clang 16\n", stdout);
  return lionss_run_workload("clang-16");
}
