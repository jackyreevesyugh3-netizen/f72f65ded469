// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("pitest run"); }
int main(){
  announce();
  return lionss_run_workload("pitest-run");
}
